
Thank You For Choosing INKFinite :)

Like us on Facebook!
www.facebook.com/INKfiniteServices

Subscribe to our Youtube channel for more FREE resetter!
www.youtube.com/c/INKfinite

-------------------INSTRUCTIONS--------------------
• Turn off any antivirus on your PC before you open the resetter (Adjprog.exe)
• Run EPSON Adjustment Program (Adjprog.exe)
• Click "Select" button and look for your printer on the "Model Name" then click "OK"
• Select "Particular adjustment mode"
• Select "Waste ink pad counter" and then click "OK"
• Check the box on the "Main pad counter"
• Then click "Initialization"
• Turn off your printer and turn it on again. Congrats!!

Best regards,
INKFinite Team